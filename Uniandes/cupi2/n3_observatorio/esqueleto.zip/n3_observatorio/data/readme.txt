Las imagenes fueron obtenidas de:

http://www.urbanzeitgeist.com/images/OrionAtlas11EQSchmidt_2DCassegrainTelescope_small.jpg
http://es.wikipedia.org/wiki/Mercurio_%28planeta%29
http://es.wikipedia.org/wiki/Venus_%28planeta%29
http://es.wikipedia.org/wiki/Tierra
http://es.wikipedia.org/wiki/Marte_%28planeta%29
http://es.wikipedia.org/wiki/J%C3%BApiter_%28planeta%29
http://es.wikipedia.org/wiki/Saturno_%28planeta%29
http://es.wikipedia.org/wiki/Urano_%28planeta%29
http://es.wikipedia.org/wiki/Neptuno_%28planeta%29