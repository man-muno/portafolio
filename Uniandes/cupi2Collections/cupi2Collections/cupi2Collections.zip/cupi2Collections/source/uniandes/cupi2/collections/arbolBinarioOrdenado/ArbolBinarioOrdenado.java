/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: ArbolBinarioOrdenado.java,v 1.10 2007/10/16 15:41:45 p-marque Exp $
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Framework: Cupi2Collections
 * Autor: Jorge Villalobos - Abr 13, 2006
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

package uniandes.cupi2.collections.arbolBinarioOrdenado;

import java.io.Serializable;

import uniandes.cupi2.collections.iterador.Iterador;
import uniandes.cupi2.collections.iterador.IteradorSimple;

/**
 * Implementaci�n de un �rbol binario ordenado
 * @param <T> Tipo de datos que contiene cada nodo del �rbol. Debe implementar la interface Comparable
 */
public class ArbolBinarioOrdenado<T extends Comparable> implements Serializable
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Ra�z del �rbol binario ordenado
     */
    private NodoArbolBinarioOrdenado<T> raiz;

    /**
     * Peso del �rbol binario ordenado
     */
    private int peso;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Constructor del �rbol binario ordenado vac�o. <br>
     * <b>post: </b> Se construy� un �rbol binario ordenado vac�o.
     */
    public ArbolBinarioOrdenado( )
    {
        raiz = null;
        peso = 0;
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Devuelve la ra�z del �rbol para navegarlo. <br>
     * <b>post: </b> Se retorn� la ra�z del �rbol para navegarlo.
     * @return Ra�z del �rbol para navegarlo
     */
    public NodoArbolBinarioOrdenado<T> darRaiz( )
    {
        return raiz;
    }

    /**
     * Agrega un nuevo elemento al �rbol binario ordenado. <br>
     * <b>pre:</b> elemento!=null. <br>
     * <b>post:</b> Se agreg� el elemento al �rbol de manera ordenada.
     * @param elemento Elemento que se va a agregar
     * @throws ElementoExisteException El elemento especificado ya existe en el �rbol
     */
    public void insertar( T elemento ) throws ElementoExisteException
    {
        if( raiz == null )
        {
            // Caso 1: el �rbol es vac�o
            raiz = new NodoArbolBinarioOrdenado<T>( elemento );
        }
        else
        {
            // Caso 2: el �rbol no es vac�o
            raiz.insertar( elemento );
        }
        peso++;
    }

    /**
     * Elimina del �rbol el elemento que llega como par�metro. <br>
     * <b>pre:</b> elemento!=null. <br>
     * <b>post:</b> Se elimin� el elemento si exist�a en la estructura.
     * @param elemento Elemento que se va a eliminar
     * @throws ElementoNoExisteException El elemento especificado no existe en el �rbol
     */
    public void eliminar( T elemento ) throws ElementoNoExisteException
    {
        if( raiz != null )
        {
            // Caso 1: el �rbol no es vac�o
            raiz = raiz.eliminar( elemento );
            peso--;
        }
        else
        {
            // Caso 2: el �rbol es vac�o
            throw new ElementoNoExisteException( "El elemento especificado no existe en el �rbol" );
        }
    }

    /**
     * Localiza y retorna un elemento del �rbol, recibiendo un modelo del mismo como par�metro. <br>
     * <b>pre:</b> modelo!=null. <br>
     * <b>post:</b> Se retorn� elemento del �rbol que corresponde al modelo o null si no encuentra el elemento.
     * @param modelo Descripci�n del elemento que se va a buscar en el �rbol. Debe contener por lo menos la informaci�n m�nima necesaria para que el m�todo de comparaci�n del
     *        nodo pueda establecer una relaci�n de orden
     * @return E elemento del �rbol que corresponde al modelo o null si no encuentra el elemento
     */
    public T buscar( T modelo )
    {
        return ( raiz != null ) ? raiz.buscar( modelo ) : null;
    }

    /**
     * Devuelve los elementos del �rbol en inorden. <br>
     * <b>post:</b> Se retorn� el iterador con los elementos del �rbol en inorden.
     * @return Iterador con los elementos del �rbol en inorden
     */
    public Iterador<T> inorden( )
    {
        IteradorSimple<T> resultado = new IteradorSimple<T>( peso );
        if( raiz != null )
        {
            raiz.inorden( resultado );
        }
        return resultado;
    }

    /**
     * Devuelve la altura del �rbol. <br>
     * <b>post:</b> Se retorn� la altura del �rbol. Entero mayor o igual a 1.
     * @return Altura del �rbol
     */
    public int darAltura( )
    {
        return ( raiz != null ) ? raiz.darAltura( ) : 0;
    }

    /**
     * Devuelve el peso del �rbol. <br>
     * <b>post:</b> Se retorn� el peso del �rbol. Entero mayor o igual a cero.
     * @return Peso del �rbol
     */
    public int darPeso( )
    {
        return peso;
    }

    /**
     * Devuelve el elemento mayor del �rbol. <br>
     * <b>post:</b> Se retorn� el elemento mayor del �rbol o null si el �rbol est� vac�o.
     * @return El elemento mayor del �rbol o null si el �rbol est� vac�o
     */
    public T darMayor( )
    {
        return ( raiz != null ) ? raiz.darMayor( ) : null;
    }

    /**
     * Devuelve el elemento menor del �rbol. <br>
     * <b>post:</b> Se retorn� el elemento menor del �rbol o null si el �rbol est� vac�o.
     * @return El elemento menor del �rbol o null si el �rbol est� vac�o
     */
    public T darMenor( )
    {
        return ( raiz != null ) ? raiz.darMenor( ) : null;
    }
}