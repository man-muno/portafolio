/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: ListaEncadenadaOrdenada.java,v 1.19 2007/10/16 15:41:45 p-marque Exp $
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Framework: Cupi2Collections
 * Autor: Jorge Villalobos - Abr 3, 2006
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

package uniandes.cupi2.collections.listaEncadenadaOrdenada;

import java.io.Serializable;

import uniandes.cupi2.collections.iterador.Iterador;
import uniandes.cupi2.collections.iterador.IteradorException;
import uniandes.cupi2.collections.iterador.IteradorSimple;

/**
 * Lista doblemente encadenada con cabeza, en la que sus elementos se encuentran ordenados. Los objetos de tipo T debe implementar la interface <b>Comparable</b>
 * @param <T> Tipo de datos a almacenar en la lista
 */
public class ListaEncadenadaOrdenada<T extends Comparable> implements Serializable
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    /**
     * Cabeza de la lista encadenada
     */
    private NodoLista<T> primero;

    /**
     * N�mero de elementos de la lista
     */
    private int numElems;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Constructor de la lista vac�a. <br>
     * <b>post: </b> Se construy� una lista vac�a.
     */
    public ListaEncadenadaOrdenada( )
    {
        primero = null;
        numElems = 0;
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Busca un elemento en la lista encadenada ordenada. <br>
     * <b>post: </b> Se retorn� el elemento o null si no existe. <br>
     * @param modelo Modelo del elemento a buscar<br>
     * @return Elemento en la lista, null si no existe<br>
     */
    public T buscar( T modelo )
    {
        for( NodoLista<T> p = primero; p != null; p = p.darSiguiente( ) )
        {
            if( p.darElemento( ).compareTo( modelo ) == 0 )
                return p.darElemento( );
        }
        return null;
    }

    /**
     * Retorna la longitud (cantidad de elementos) de la lista encadenada ordenada. <br>
     * <b>post: </b> Se retorn� la longitud de la lista.<br>
     * @return Longitud de la lista. Entero mayor o igual a cero.<br>
     */
    public int darLongitud( )
    {
        return numElems;
    }

    /**
     * Retorna el primer nodo de la lista. <br>
     * <b>post: </b> Se retorn� el primer nodo de la lista.<br>
     * @return Primer nodo de la lista. Puede ser null en caso que la lista sea vac�a.<br>
     */
    public NodoLista<T> darPrimero( )
    {
        return primero;
    }

    /**
     * Inserta el elemento en la lista en la posici�n que le corresponde. <br>
     * <b>post: </b> Se insert� el elemento en la posici�n que le corresponde dentro de la lista de acuerdo a la relaci�n de orden existente entre los elementos de tipo T.<br>
     * @param elemento Elemento a insertar<br>
     */
    public void insertar( T elemento )
    {
        NodoLista<T> nodo = new NodoLista<T>( elemento );
        if( primero == null )
        {
            primero = nodo;
        }
        else if( elemento.compareTo( primero.darElemento( ) ) < 0 )
        {
            // Debe quedar como primer elemento de la lista
            primero.insertarAntes( nodo );
            primero = nodo;
        }
        else
        {
            NodoLista<T> p = primero;
            for( ; p.darSiguiente( ) != null && p.darSiguiente( ).darElemento( ).compareTo( elemento ) < 0; p = p.darSiguiente( ) )
                ;
            p.insertarDespues( nodo );
        }
        numElems++;
    }

    /**
     * Elimina el elemento especificado de la lista encadenada ordenada. <br>
     * <b>post: </b> Se elimin� el elemento especificado de la lista.<br>
     * @param elemento Elemento a eliminar<br>
     * @throws NoExisteException Si el elemento especificado no existe<br>
     */
    public void eliminar( T elemento ) throws NoExisteException
    {
        if( primero == null )
        {
            throw new NoExisteException( "Elemento no existe" );
        }
        else if( elemento.compareTo( primero.darElemento( ) ) == 0 )
        {
            // Se debe eliminar el primer elemento de la lista
            primero = primero.desconectarPrimero( );
            numElems--;
        }
        else
        {
            for( NodoLista<T> p = primero.darSiguiente( ); p != null; p = p.darSiguiente( ) )
            {
                if( p.darElemento( ).compareTo( elemento ) == 0 )
                {
                    p.desconectarNodo( );
                    numElems--;
                    return;
                }
            }
            throw new NoExisteException( "Elemento no existe" );
        }
    }

    /**
     * Elimina todos los elementos de la lista.<br>
     * <b>post: </b> La lista ahora es vac�a. primero = null, numElems = 0<br>
     */
    public void vaciar( )
    {
        primero = null;
        numElems = 0;
    }

    /**
     * Convierte la lista a un String. <br>
     * <b>post: </b> Se retorn� la representaci�n en String de la lista. El String tiene el formato "[numeroElementos]: e1<->e2<->e3..<->en", donde e1, e2, ..., en son los
     * elementos que contiene la lista y numeroElementos su longitud. <br>
     * @return La representaci�n en String de la lista
     */
    @Override
    public String toString( )
    {
        String resp = "[" + numElems + "]:";
        for( NodoLista<T> p = primero; p != null; p = p.darSiguiente( ) )
        {
            resp += p.darElemento( ).toString( ) + "<->";
        }
        return resp;
    }

    /**
     * Devuelve un iterador con los elementos de la lista encadenada ordenada. <br>
     * <b>post:</b> Se retorn� iterador con los elementos de la lista.<br>
     * @return Iterador con los elementos de la lista, puede ser vac�o pero no null.<br>
     */
    public Iterador<T> darIterador( )
    {
        IteradorSimple<T> respuesta = new IteradorSimple<T>( numElems );
        NodoLista<T> iterador = primero;
        while( iterador != null )
        {
            try
            {
                respuesta.agregar( iterador.darElemento( ) );
                iterador = iterador.darSiguiente( );
            }
            catch( IteradorException e )
            {
                // Nunca deber�a ocurrir esta excepci�n
            }
        }
        return respuesta;
    }

    /**
     * Verifica que la lista es igual a un objeto pasado por par�metro.<br>
     * @param obj Objeto que se quiere comprar<br>
     * @return True en caso que el objeto que se para por par�metro sea de tipo ListaEncadenadaOrdenada, tenga el mismo tama�o y todos sus elementos sean iguales (usando el
     *         m�todo equals).<br>
     */
    public boolean equals( Object obj )
    {
        if( obj == null )
            return false;
        try
        {
            ListaEncadenadaOrdenada lista = ( ListaEncadenadaOrdenada )obj;
            if( numElems != lista.numElems )
                return false;
            NodoLista iterador = primero;
            NodoLista porComparar = lista.primero;
            while( iterador != null )
            {
                if( !iterador.equals( porComparar ) )
                    return false;
                iterador.darSiguiente( );
                porComparar.darSiguiente( );
            }
        }
        catch( ClassCastException e )
        {
            // Excepci�n que se atrapa si el objeto no es de tipo ListaEncadenadaOrdenada
            return false;
        }
        return true;
    }
}
