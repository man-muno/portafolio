/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: Conjunto.java,v 1.11 2007/10/16 15:41:45 p-marque Exp $
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Framework: Cupi2Collections
 * Autor: Jorge Villalobos - Abr 11, 2006
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

package uniandes.cupi2.collections.conjunto;

import java.io.Serializable;

import uniandes.cupi2.collections.iterador.Iterador;
import uniandes.cupi2.collections.lista.IndiceFueraDeRangoException;
import uniandes.cupi2.collections.lista.Lista;

/**
 * Implementaci�n de un conjunto
 * @param <T> Tipo de datos que contiene el conjunto. Los objetos de tipo T deben tener bien definido el m�todo <b>equals</b>
 */
public class Conjunto<T> implements Serializable
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Elementos del conjunto
     */
    private Lista<T> elems;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Constructor del conjunto vac�o. <br>
     * <b>post: </b> Se construy� un conjunto vac�o.
     */
    public Conjunto( )
    {
        elems = new Lista<T>( );
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Inserta el elemento especificado en el conjunto. <br>
     * <b>pre: </b> elem!=null. <br>
     * <b>post: </b> Se retorn� true si el elemento fue insertado o false en caso contrario. Un elemento no es adicionado si �ste ya existe en el conjunto.<br>
     * @return True si el elemento fue insertado o false en caso contrario
     */
    public boolean insertar( T elem )
    {
        if( elems.buscar( elem ) != -1 )
            return false;
        else
        {
            elems.agregar( elem );
            return true;
        }
    }

    /**
     * Elimina el elemento especificado del conjunto. <br>
     * <b>pre: </b> elem!=null. <br>
     * <b>post: </b> Se retorn� true si el elemento fue eliminado del conjunto o false en caso contrario. Un elemento no es eliminado si �ste no existe en el conjunto. <br>
     * @return True si el elemento fue eliminado o false en caso contrario
     */
    public boolean eliminar( T elem )
    {
        try
        {
            return elems.eliminar( elem ) != null ? true : false;
        }
        catch( IndiceFueraDeRangoException e )
        {
            return false;
        }
    }

    /**
     * Busca el elemento especificado en el conjunto. <br>
     * <b>pre: </b> elem!=null. <br>
     * <b>post: </b> Se retorn� true si el elemento existe en el conjunto o false en caso contrario.
     * @return True si el elemento se encontr� en el conjunto o false en caso contrario
     */
    public boolean buscar( T elem )
    {
        return elems.buscar( elem ) != -1;
    }

    /**
     * Retorna la cardinalidad del conjunto (el n�mero de elementos). <br>
     * <b>post: </b> Se retorn� la cardinalidad del conjunto.
     * @return La cardinalidad del conjunto. Entero positivo mayor o igual a cero.
     */
    public int cardinalidad( )
    {
        return elems.darLongitud( );
    }

    /**
     * Indica si el conjunto es vac�o (el n�mero de elementos es cero). <br>
     * <b>post: </b> Se retorn� true si el conjunto es vac�o o false en caso contrario.
     * @return True si el conjunto es vac�o o false en caso contrario<br>
     */
    public boolean vacio( )
    {
        return elems.darLongitud( ) == 0;
    }

    /**
     * Retorna un iterador para recorrer los elementos del conjunto. <br>
     * <b>post: </b> Se retorn� el iterador para recorrer los elementos del conjunto.
     * @return El iterador para recorrer los elementos del conjunto
     */
    public Iterador<T> darIterador( )
    {
        return elems.darIterador( );
    }

    /**
     * Convierte el conjunto a un String. <br>
     * <b>post: </b> Se retorn� la representaci�n en String del conjunto. El String tiene el formato "[numeroElementos]: e1-e2-e3..-en", donde e1, e2, ..., en son los
     * elementos que contiene el conjunto y numeroElementos su cardinalidad.
     * @return La representaci�n en String del conjunto
     */
    @Override
    public String toString( )
    {
        return elems.toString( );
    }
}
