package uniandes.cupi2.collections.arbolB.test;

import junit.framework.TestCase;
import uniandes.cupi2.collections.arbolB.test.VerificadorEstructura;
import uniandes.cupi2.collections.arbolB.ArbolB;
import uniandes.cupi2.collections.arbolB.ElementoExisteException;
import uniandes.cupi2.collections.arbolB.ElementoNoExisteException;
import uniandes.cupi2.collections.arbolB.NodoB;
import uniandes.cupi2.collections.iterador.Iterador;

/**
 * Esta es la clase usada para verificar los m�todos de la clase �rbol B
 */
public class ArbolBTest extends TestCase
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    /**
     * Es la clase donde se har�n las pruebas
     */
    private ArbolB arbol;

    /**
     * El n�mero de elementos a manejar en cada escenario
     */
    private int numeroElementos;

    /**
     * Objeto para verificar el invariante de la estructura
     */
    private VerificadorEstructura verificador;

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Construye un �rbol vac�o
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario1Orden3( )
    {
        arbol = new ArbolB<Long>( 3 );
        numeroElementos = 0;
        verificador = new VerificadorEstructura<Long>( );
    }

    /**
     * Construye un �rbol con 11 nodos
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario2Orden3( )
    {
        arbol = new ArbolB<Long>( 3 );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            arbol.insertar( elementos[ 5 ] );
            arbol.insertar( elementos[ 4 ] );
            arbol.insertar( elementos[ 6 ] );
            arbol.insertar( elementos[ 3 ] );
            arbol.insertar( elementos[ 7 ] );
            arbol.insertar( elementos[ 2 ] );
            arbol.insertar( elementos[ 1 ] );
            arbol.insertar( elementos[ 8 ] );
            arbol.insertar( elementos[ 9 ] );
            arbol.insertar( elementos[ 0 ] );
            arbol.insertar( elementos[ 10 ] );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
        numeroElementos = 11;
        verificador = new VerificadorEstructura<Long>( );
    }

    /**
     * Construye un �rbol con 5 nodos
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario3Orden3( )
    {
        arbol = new ArbolB<Long>( 3 );

        try
        {
            arbol.insertar( new Long( -8 ) );
            arbol.insertar( new Long( -11 ) );
            arbol.insertar( new Long( -12 ) );
            arbol.insertar( new Long( -19 ) );
            arbol.insertar( new Long( -20 ) );

        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
        numeroElementos = 5;
        verificador = new VerificadorEstructura<Long>( );
    }

    /**
     * Construye un �rbol con 1 nodo
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario4Orden3( )
    {
        arbol = new ArbolB<Long>( 3 );

        try
        {
            arbol.insertar( new Long( -800 ) );
            numeroElementos = 1;
            verificador = new VerificadorEstructura<Long>( );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Construye un �rbol con 3 nodo
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario5Orden3( )
    {
        arbol = new ArbolB<Long>( 3 );

        try
        {
            arbol.insertar( new Long( 2 ) );
            arbol.insertar( new Long( 30 ) );
            arbol.insertar( new Long( 15 ) );
            numeroElementos = 1;
            verificador = new VerificadorEstructura<Long>( );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }
    /**
     * Construye un �rbol vac�o
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario1Orden4( )
    {
        arbol = new ArbolB<Long>( 4 );
        numeroElementos = 0;
        verificador = new VerificadorEstructura<Long>( );
    }

    /**
     * Construye un �rbol con 11 nodos
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario2Orden4( )
    {
        arbol = new ArbolB<Long>( 4 );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {

            arbol.insertar( elementos[ 3 ] );
            arbol.insertar( elementos[ 7 ] );
            arbol.insertar( elementos[ 2 ] );
            arbol.insertar( elementos[ 1 ] );
            arbol.insertar( elementos[ 8 ] );
            arbol.insertar( elementos[ 5 ] );
            arbol.insertar( elementos[ 4 ] );
            arbol.insertar( elementos[ 6 ] );
            arbol.insertar( elementos[ 9 ] );
            arbol.insertar( elementos[ 0 ] );
            arbol.insertar( elementos[ 10 ] );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
        numeroElementos = 11;
        verificador = new VerificadorEstructura<Long>( );
    }

    /**
     * Construye un �rbol con 5 nodos
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario3Orden4( )
    {
        arbol = new ArbolB<Long>( 4 );

        try
        {
            arbol.insertar( new Long( -8 ) );
            arbol.insertar( new Long( -11 ) );
            arbol.insertar( new Long( -12 ) );
            arbol.insertar( new Long( -19 ) );
            arbol.insertar( new Long( -20 ) );

        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
        numeroElementos = 5;
        verificador = new VerificadorEstructura<Long>( );
    }

    /**
     * Construye un �rbol con 1 nodo
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario4Orden4( )
    {
        arbol = new ArbolB<Long>( 4 );

        try
        {
            arbol.insertar( new Long( -800 ) );
            numeroElementos = 1;
            verificador = new VerificadorEstructura<Long>( );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Construye un �rbol con 3 nodo
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario5Orden4( )
    {
        arbol = new ArbolB<Long>( 4 );

        try
        {
            arbol.insertar( new Long( 2 ) );
            arbol.insertar( new Long( 30 ) );
            arbol.insertar( new Long( 15 ) );
            numeroElementos = 1;
            verificador = new VerificadorEstructura<Long>( );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verifica que la estructura y el orden se mantengan en el �rbol 2_3
     * 
     */
    @SuppressWarnings("unchecked")
    private void verificarInvariante( )
    {
        boolean estructuraBien = verificador.verificarArbol( arbol );

        assertTrue( "La estructura y/o el orden en el �rbol no es correcto", estructuraBien );
    }

    /**
     * Verifica que las inserciones se est�n realizando correctamente en el �rbol
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsertar1Orden3( )
    {
        setupEscenario1Orden3( );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            // Inserci�n
            arbol.insertar( elementos[ 5 ] );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol

            NodoB raiz = arbol.darRaiz( );
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );

            // Inserci�n
            arbol.insertar( elementos[ 4 ] );

            raiz = arbol.darRaiz( );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 6 ] );

            raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 3 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 7 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 2 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 1 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 8 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            NodoB hijo1_1 = hijo1.darHijo( 0 );
            NodoB hijo1_2 = hijo1.darHijo( 1 );
            NodoB hijo1_3 = hijo1.darHijo( 2 );

            NodoB hijo2_1 = hijo2.darHijo( 0 );
            NodoB hijo2_2 = hijo2.darHijo( 1 );
            NodoB hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3 );

            assertNull( "El elemento deber�a ser null", hijo3 );

            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 9 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3 );

            assertNull( "El elemento deber�a ser null", hijo3 );

            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 0 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3 );

            assertNull( "El elemento deber�a ser null", hijo3 );

            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 10 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );

            verificarInvariante( );

            // Verificar que el �rbol �ste bien construido con el recorrido en inorden
            Iterador iterador = arbol.inorden( );

            int cont = 0;
            while( iterador.haySiguiente( ) )
            {
                Long elemento = ( Long )iterador.darSiguiente( );

                assertEquals( "No se insertaron en orden correcto los elementos", elementos[ cont ], elemento );
                cont++;
            }

        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verifica que no se permita la inserci�n (que se arroje excepci�n) de elementos que ya existan en el �rbol 2_3
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsercion2Orden3( )
    {
        setupEscenario2Orden3( );

        try
        {
            arbol.insertar( new Long( 5 ) );

            assertTrue( "No se debi� realizar la inserci�n del elemento", false );

        }
        catch( ElementoExisteException e )
        {

            assertTrue( "No se debi� realizar la inserci�n del elemento", true );
            verificarInvariante( );
        }
    }

    /**
     * Verifica la inserci�n en el �rbol adicionando s�lo elementos menores a la ra�z
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsercion3Orden3( )
    {
        setupEscenario1Orden3( );

        try
        {
            // Inserci�n
            arbol.insertar( new Long( -8 ) );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol

            NodoB raiz = arbol.darRaiz( );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -11 ) );

            raiz = arbol.darRaiz( );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )raiz.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -12 ) );

            raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -19 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -20 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );

            verificarInvariante( );

        }
        catch( ElementoExisteException e )
        {

            assertTrue( "No se debi� realizar la inserci�n del elemento", true );
        }
    }

    /**
     * Verifica que la altura del �rbol se genere correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testDarAlturaOrden3( )
    {
        setupEscenario2Orden3( );

        int altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 3, altura );

        setupEscenario1Orden3( );
        altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 0, altura );

        setupEscenario3Orden3( );
        altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 2, altura );

        setupEscenario4Orden3( );
        altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 1, altura );

    }

    /**
     * Verifica que la b�squeda de un elemento se realice correctamente en el �rbol 2_3
     * 
     */
    @SuppressWarnings("unchecked")
    public void testBuscarOrden3( )
    {
        setupEscenario2Orden3( );
        Long elemento;
        Long respuesta;

        for( int cont = 0; cont < numeroElementos; cont++ )
        {
            elemento = new Long( cont );
            respuesta = ( Long )arbol.buscar( elemento );
            assertEquals( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", elemento, respuesta );
        }

        // Verificar que al buscar un elemento que no exista se retorne null
        elemento = new Long( 1000 );
        respuesta = ( Long )arbol.buscar( elemento );
        assertNull( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", respuesta );

        setupEscenario2Orden3( );
        respuesta = ( Long )arbol.buscar( elemento );
        assertNull( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", respuesta );

        // Realizar la b�squeda de elemetos solos
        setupEscenario3Orden3( );
        elemento = new Long( -8 );
        respuesta = ( Long )arbol.buscar( elemento );
        assertEquals( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", elemento, respuesta );
    }

    /**
     * Verifica que el peso se retorne correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testDarPesoOrden3( )
    {
        setupEscenario1Orden3( );

        int peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );

        setupEscenario2Orden3( );
        peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );

        setupEscenario3Orden3( );

        peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );

        setupEscenario4Orden3( );

        peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );
    }

    /**
     * Verifica que se recorra el �rbol en inorden de forma correcta
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInordenOrden3( )
    {
        setupEscenario2Orden3( );

        Iterador iterador = arbol.inorden( );

        // Verificar que el recorrido en inorden sea correcto
        int cont = 0;
        while( iterador.haySiguiente( ) )
        {

            Long elemento = ( Long )iterador.darSiguiente( );

            assertEquals( "El elemento retornado no es el correcto", new Long( cont ), elemento );
            cont++;
        }

        // Verificar que se hayan recorrido todos los elementos
        assertEquals( "No se recorrieron todos los elementos en el inorden", numeroElementos, cont );

        setupEscenario1Orden3( );
        iterador = arbol.inorden( );
        assertFalse( "No se debi� haber recorrido elemento alguno", iterador.haySiguiente( ) ); // Verificar que no se haya recorrido nada

        // Verificar que se retorne el �nico elemento del �rbol
        setupEscenario4Orden3( );
        iterador = arbol.inorden( );
        assertEquals( "El peso no es correcto", new Long( -800 ), iterador.darSiguiente( ) );
    }

    /**
     * Verifica que todos los elementos del �rbol sean eliminados de forma correcta
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar1Orden3( )
    {
        setupEscenario2Orden3( );

        try
        {
            for( int cont = 0; cont < numeroElementos; cont++ )
            {
                arbol.eliminar( new Long( cont ) );
                verificarInvariante( );
            }

            // Verificar que se hayan eliminado todos los elementos
            for( int cont = 6; cont < numeroElementos + 8; cont++ )
            {

                if( cont != 13 && cont != 14 )
                {
                    Long elemento = ( Long )arbol.buscar( new Long( cont ) );
                    assertNull( "No se debi� haber retornado el elemento", elemento );

                }
            }

            // Verificar que se hayan eliminado todos los elementos
            assertEquals( "El peso no es correcto", 0, arbol.darPeso( ) );

            setupEscenario4Orden3( );
            arbol.eliminar( new Long( -800 ) );

            // Verificar que se hayan eliminado todos los elementos
            assertEquals( "El peso no es correcto", 0, arbol.darPeso( ) );
            verificarInvariante( );

            setupEscenario3Orden3( );
            arbol.eliminar( new Long( -8 ) );

            // Verificar que se hayan eliminado todos los elementos
            assertEquals( "El peso no es correcto", numeroElementos - 1, arbol.darPeso( ) );
            verificarInvariante( );

            // buscar el elemento que se acabo de eliminar
            Long elemento = ( Long )arbol.buscar( new Long( -1 ) );
            assertNull( "No se debi� haber retornado el elemento", elemento );

        }
        catch( ElementoNoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verifica que se arroje excepci�n al tratar de eliminar un elemento que no existe
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar2Orden3( )
    {
        setupEscenario2Orden3( );

        try
        {
            arbol.eliminar( new Long( 10000 ) );
            assertTrue( "No se debi� eliminar el elemento", false );

        }
        catch( ElementoNoExisteException e )
        {

            // Verificar que se hayan eliminado todos los elementos
            assertTrue( "No se debi� eliminar el elemento", true );
            verificarInvariante( );
            setupEscenario4Orden3( );
            try
            {
                arbol.eliminar( new Long( 15 ) );
                assertTrue( "No se debi� eliminar el elemento", false );
            }
            catch( ElementoNoExisteException e1 )
            {
                assertTrue( "No se debi� eliminar el elemento", true );
                verificarInvariante( );
            }

        }
    }

    /**
     * Verifica que todos los elementos de que se encuentran en las hojas se eliminen correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar3Orden3( )
    {
        setupEscenario2Orden3( );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            // Eliminaci�n caso A
            arbol.insertar( new Long( 11 ) );
            arbol.eliminar( new Long( 11 ) );

            NodoB raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );
            NodoB hijo1_1 = hijo1.darHijo( 0 );
            NodoB hijo1_2 = hijo1.darHijo( 1 );
            NodoB hijo1_3 = hijo1.darHijo( 2 );

            NodoB hijo2_1 = hijo2.darHijo( 0 );
            NodoB hijo2_2 = hijo2.darHijo( 1 );
            NodoB hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminaci�n caso B
            arbol.insertar( new Long( -1 ) );
            arbol.eliminar( new Long( -1 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminaci�n caso C
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -13 ) );
            arbol.eliminar( new Long( -20 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -13", new Long( -13 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso D
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -10 ) );
            arbol.eliminar( new Long( -20 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -10", new Long( -10 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso E
            setupEscenario3Orden3( );
            arbol.eliminar( new Long( -20 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminaci�n caso F
            setupEscenario3Orden3( );
            arbol.eliminar( new Long( -8 ) );
            arbol.eliminar( new Long( -11 ) );
            arbol.eliminar( new Long( -20 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminaci�n caso G
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -13 ) );
            arbol.eliminar( new Long( -13 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso H
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -13 ) );
            arbol.eliminar( new Long( -12 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -13", new Long( -13 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso I

            setupEscenario5Orden3( );
            arbol.insertar( new Long( 8 ) );
            arbol.eliminar( new Long( 30 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 8", new Long( 8 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", new Long( 2 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 15", new Long( 15 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );

            // Eliminaci�n caso H
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -10 ) );
            arbol.eliminar( new Long( -12 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -10", new Long( -10 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso K
            setupEscenario3Orden3( );
            arbol.eliminar( new Long( -12 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminaci�n caso L
            setupEscenario3Orden3( );
            arbol.eliminar( new Long( -8 ) );
            arbol.eliminar( new Long( -11 ) );
            arbol.eliminar( new Long( -12 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 1 ) ); // Verificar el contenido de los nodos
            verificarInvariante( );

            // Eliminaci�n caso M
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -10 ) );
            arbol.eliminar( new Long( -8 ) );
            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            verificarInvariante( );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -10", new Long( -10 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso N
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -10 ) );
            arbol.eliminar( new Long( -10 ) );
            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso O
            setupEscenario3Orden3( );
            arbol.insertar( new Long( -13 ) );
            arbol.eliminar( new Long( -8 ) );
            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -13", new Long( -13 ), ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3.darRaiz( 1 ) );
            verificarInvariante( );

            // Eliminaci�n caso P
            setupEscenario3Orden3( );
            arbol.eliminar( new Long( -8 ) );
            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -12", new Long( -11 ), ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );
        }
        catch( ElementoNoExisteException e )
        {
            fail( e.getMessage( ) );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }

    }

    /**
     * Verifica que los elementos que no se encuentran en las hojas se eliminen correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar4Orden3( )
    {
        setupEscenario2Orden3( );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            // Caso R
            arbol.eliminar( elementos[ 3 ] );

            NodoB raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );
            NodoB hijo1_1 = hijo1.darHijo( 0 );
            NodoB hijo1_2 = hijo1.darHijo( 1 );
            NodoB hijo1_3 = hijo1.darHijo( 2 );
            NodoB hijo2_1 = hijo2.darHijo( 0 );
            NodoB hijo2_2 = hijo2.darHijo( 1 );
            NodoB hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Caso Q
            setupEscenario2Orden3( );
            arbol.eliminar( elementos[ 1 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminar un elemento de la ra�z
            setupEscenario2Orden3( );
            arbol.eliminar( elementos[ 5 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminar el 7
            setupEscenario2Orden3( );
            arbol.eliminar( elementos[ 7 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Eliminar el 9
            setupEscenario2Orden3( );
            arbol.eliminar( elementos[ 9 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], hijo1_3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 10 ], ( Long )hijo2_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

        }
        catch( ElementoNoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verifica que las inserciones se est�n realizando correctamente en el �rbol
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsertar1Orden4( )
    {
        setupEscenario1Orden4( );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            // Inserci�n
            arbol.insertar( elementos[ 5 ] );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol

            NodoB raiz = arbol.darRaiz( );
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );

            // Inserci�n
            arbol.insertar( elementos[ 4 ] );

            raiz = arbol.darRaiz( );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 6 ] );

            raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );
            NodoB hijo4 = raiz.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo1 );
            assertNull( "El elemento deber�a ser null", hijo2 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 3 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo3 = raiz.darHijo( 4 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 7 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 2 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 1 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 8 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            NodoB hijo1_1 = hijo1.darHijo( 0 );
            NodoB hijo1_2 = hijo1.darHijo( 1 );
            NodoB hijo1_3 = hijo1.darHijo( 2 );
            NodoB hijo1_4 = hijo1.darHijo( 3 );

            NodoB hijo2_1 = hijo2.darHijo( 0 );
            NodoB hijo2_2 = hijo2.darHijo( 1 );
            NodoB hijo2_3 = hijo2.darHijo( 2 );
            NodoB hijo2_4 = hijo2.darHijo( 3 );

            NodoB hijo3_1 = hijo3.darHijo( 0 );
            NodoB hijo3_2 = hijo3.darHijo( 1 );
            NodoB hijo3_3 = hijo3.darHijo( 2 );
            NodoB hijo3_4 = hijo3.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 9 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo3.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo3.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            // Inserci�n
            arbol.insertar( elementos[ 0 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            NodoB hijo4_1 = hijo4.darHijo( 0 );
            NodoB hijo4_2 = hijo4.darHijo( 1 );
            NodoB hijo4_3 = hijo4.darHijo( 2 );
            NodoB hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );

            verificarInvariante( );

            // Inserci�n
            arbol.insertar( elementos[ 10 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 3, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );

            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1_1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1_2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2_1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo2_2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo2_3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo2_3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_4 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Verificar que el �rbol �ste bien construido con el recorrido en inorden
            Iterador iterador = arbol.inorden( );

            int cont = 0;
            while( iterador.haySiguiente( ) )
            {
                Long elemento = ( Long )iterador.darSiguiente( );

                assertEquals( "No se insertaron en orden correcto los elementos", elementos[ cont ], elemento );
                cont++;
            }

        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verifica que no se permita la inserci�n (que se arroje excepci�n) de elementos que ya existan en el �rbol 2_3
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsercion2Orden4( )
    {
        setupEscenario2Orden4( );

        try
        {
            arbol.insertar( new Long( 5 ) );

            assertTrue( "No se debio realizar la inserci�n del elemento", false );

        }
        catch( ElementoExisteException e )
        {

            assertTrue( "No se debio realizar la inserci�n del elemento", true );
            verificarInvariante( );
        }
    }

    /**
     * Verifica la inserci�n en el �rbol adicionando s�lo elementos menores a la ra�z
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsercion3Orden4( )
    {
        setupEscenario1Orden4( );

        try
        {
            // Inserci�n
            arbol.insertar( new Long( -8 ) );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol

            NodoB raiz = arbol.darRaiz( );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -11 ) );

            raiz = arbol.darRaiz( );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )raiz.darRaiz( 1 ) );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -12 ) );

            raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )raiz.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo1 );
            assertNull( "El elemento deber�a ser null", hijo2 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -19 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );
            verificarInvariante( );

            // Inserci�n
            arbol.insertar( new Long( -20 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser -12", new Long( -12 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertNull( "El elemento deber�a ser null", raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -20", new Long( -20 ), ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -19", new Long( -19 ), ( Long )hijo1.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser -11", new Long( -11 ), ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser -8", new Long( -8 ), ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3 );

            verificarInvariante( );

        }
        catch( ElementoExisteException e )
        {

            assertTrue( "No se debi� realizar la inserci�n del elemento", true );
        }
    }

    /**
     * Verifica que la altura del �rbol se genere correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testDarAlturaOrden4( )
    {
        setupEscenario2Orden4( );

        int altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 2, altura );

        setupEscenario1Orden4( );
        altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 0, altura );

        setupEscenario3Orden4( );
        altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 2, altura );

        setupEscenario4Orden4( );
        altura = arbol.darAltura( );

        assertEquals( "La altura retornada no es correcta", 1, altura );

    }

    /**
     * Verifica que la b�squeda de un elemento se realice correctamente en el �rbol 2_3
     * 
     */
    @SuppressWarnings("unchecked")
    public void testBuscarOrden4( )
    {
        setupEscenario2Orden4( );
        Long elemento;
        Long respuesta;

        for( int cont = 0; cont < numeroElementos; cont++ )
        {
            elemento = new Long( cont );
            respuesta = ( Long )arbol.buscar( elemento );
            assertEquals( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", elemento, respuesta );
        }

        // Verificar que al buscar un elemento que no exista se retorne null
        elemento = new Long( 1000 );
        respuesta = ( Long )arbol.buscar( elemento );
        assertNull( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", respuesta );

        setupEscenario2Orden4( );
        respuesta = ( Long )arbol.buscar( elemento );
        assertNull( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", respuesta );

        // Realizar la b�squeda de elemetos solos
        setupEscenario3Orden4( );
        elemento = new Long( -8 );
        respuesta = ( Long )arbol.buscar( elemento );
        assertEquals( "No se retorno el elemento correcto en la realizaci�n de la b�squeda", elemento, respuesta );
    }

    /**
     * Verifica que el peso se retorne correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testDarPesoOrden4( )
    {
        setupEscenario1Orden4( );

        int peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );

        setupEscenario2Orden4( );
        peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );

        setupEscenario3Orden4( );

        peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );

        setupEscenario4Orden4( );

        peso = arbol.darPeso( );

        assertEquals( "El peso no es correcto", numeroElementos, peso );
    }

    /**
     * Verifica que se recorra el �rbol en inorden de forma correcta
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInordenOrden4( )
    {
        setupEscenario2Orden4( );

        Iterador iterador = arbol.inorden( );

        // Verificar que el recorrido en inorden sea correcto
        int cont = 0;
        while( iterador.haySiguiente( ) )
        {

            Long elemento = ( Long )iterador.darSiguiente( );

            assertEquals( "El elemento retornado no es el correcto", new Long( cont ), elemento );
            cont++;
        }

        // Verificar que se hayan recorrido todos los elementos
        assertEquals( "No se recorrieron todos los elementos en el inorden", numeroElementos, cont );

        setupEscenario1Orden4( );
        iterador = arbol.inorden( );
        assertFalse( "No se debi� haber recorrido elemento alguno", iterador.haySiguiente( ) ); // Verificar que no se haya recorrido nada

        // Verificar que se retorne el �nico elemento del �rbol
        setupEscenario4Orden4( );
        iterador = arbol.inorden( );
        assertEquals( "El peso no es correcto", new Long( -800 ), iterador.darSiguiente( ) );
    }

    /**
     * Verifica que todos los elementos del �rbol sean eliminados de forma correcta
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar1Orden4( )
    {
        setupEscenario2Orden4( );

        try
        {
            for( int cont = 0; cont < numeroElementos; cont++ )
            {
                arbol.eliminar( new Long( cont ) );
                verificarInvariante( );
            }

            // Verificar que se hayan eliminado todos los elementos
            for( int cont = 6; cont < numeroElementos + 8; cont++ )
            {

                if( cont != 13 && cont != 14 )
                {
                    Long elemento = ( Long )arbol.buscar( new Long( cont ) );
                    assertNull( "No se debi� haber retornado el elemento", elemento );

                }
            }

            // Verificar que se hayan eliminado todos los elementos
            assertEquals( "El peso no es correcto", 0, arbol.darPeso( ) );

            setupEscenario4Orden4( );
            arbol.eliminar( new Long( -800 ) );

            // Verificar que se hayan eliminado todos los elementos
            assertEquals( "El peso no es correcto", 0, arbol.darPeso( ) );
            verificarInvariante( );

            setupEscenario3Orden4( );
            arbol.eliminar( new Long( -8 ) );

            // Verificar que se hayan eliminado todos los elementos
            assertEquals( "El peso no es correcto", numeroElementos - 1, arbol.darPeso( ) );
            verificarInvariante( );

            // buscar el elemento que se acabo de eliminar
            Long elemento = ( Long )arbol.buscar( new Long( -1 ) );
            assertNull( "No se debi� haber retornado el elemento", elemento );

        }
        catch( ElementoNoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verifica que se arroje excepci�n al tratar de eliminar un elemento que no existe
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar2Orden4( )
    {
        setupEscenario2Orden4( );

        try
        {
            arbol.eliminar( new Long( 10000 ) );
            assertTrue( "No se debi� eliminar el elemento", false );

        }
        catch( ElementoNoExisteException e )
        {

            // Verificar que se hayan eliminado todos los elementos
            assertTrue( "No se debi� eliminar el elemento", true );
            verificarInvariante( );
            setupEscenario4Orden4( );
            try
            {
                arbol.eliminar( new Long( 15 ) );
                assertTrue( "No se debi� eliminar el elemento", false );
            }
            catch( ElementoNoExisteException e1 )
            {
                assertTrue( "No se debi� eliminar el elemento", true );
                verificarInvariante( );
            }

        }
    }

    /**
     * Verifica que todos los elementos de que se encuentran en las hojas se eliminen correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar3Orden4( )
    {
        setupEscenario2Orden4( );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            // Eliminaci�n caso A
            arbol.eliminar( new Long( 1 ) );

            NodoB raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );
            NodoB hijo4 = raiz.darHijo( 3 );
            NodoB hijo1_1 = hijo1.darHijo( 0 );
            NodoB hijo1_2 = hijo1.darHijo( 1 );
            NodoB hijo1_3 = hijo1.darHijo( 2 );
            NodoB hijo1_4 = hijo1.darHijo( 3 );

            NodoB hijo2_1 = hijo2.darHijo( 0 );
            NodoB hijo2_2 = hijo2.darHijo( 1 );
            NodoB hijo2_3 = hijo2.darHijo( 2 );
            NodoB hijo2_4 = hijo2.darHijo( 3 );

            NodoB hijo3_1 = hijo3.darHijo( 0 );
            NodoB hijo3_2 = hijo3.darHijo( 1 );
            NodoB hijo3_3 = hijo3.darHijo( 2 );
            NodoB hijo3_4 = hijo3.darHijo( 3 );

            NodoB hijo4_1 = hijo4.darHijo( 0 );
            NodoB hijo4_2 = hijo4.darHijo( 1 );
            NodoB hijo4_3 = hijo4.darHijo( 2 );
            NodoB hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso B
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 0 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso C
            arbol.eliminar( new Long( 1 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso D
            arbol.eliminar( new Long( 2 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso E
            arbol.eliminar( new Long( 9 ) );
            arbol.eliminar( new Long( 3 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Eliminaci�n caso F
            arbol.eliminar( new Long( 10 ) );
            arbol.eliminar( new Long( 8 ) );
            arbol.eliminar( new Long( 7 ) );
            arbol.eliminar( new Long( 4 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1 );
            assertNull( "El elemento deber�a ser null", hijo2 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Eliminaci�n caso G
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 4 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso F
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 3 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso H

            arbol.eliminar( new Long( 0 ) );
            arbol.eliminar( new Long( 4 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso I
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 3 ) );
            arbol.eliminar( new Long( 4 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso K
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 4 ) );
            arbol.eliminar( new Long( 9 ) );
            arbol.eliminar( new Long( 10 ) );
            arbol.eliminar( new Long( 6 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Eliminaci�n caso L
            arbol.eliminar( new Long( 8 ) );
            arbol.eliminar( new Long( 7 ) );
            arbol.eliminar( new Long( 0 ) );
            arbol.eliminar( new Long( 5 ) );
            arbol.eliminar( new Long( 3 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 1, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1 );
            assertNull( "El elemento deber�a ser null", hijo2 );
            assertNull( "El elemento deber�a ser null", hijo3 );
            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Eliminaci�n caso M
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 10 ) );
            arbol.eliminar( new Long( 9 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo4.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso N
            setupEscenario2Orden4( );
            arbol.eliminar( new Long( 10 ) );
            arbol.eliminar( new Long( 8 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Eliminaci�n caso P
            arbol.eliminar( new Long( 9 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Eliminaci�n caso O

            setupEscenario5Orden4( );
            arbol.insertar( new Long( 7 ) );
            arbol.insertar( new Long( 3 ) );
            arbol.insertar( new Long( 6 ) );
            arbol.insertar( new Long( 4 ) );
            arbol.insertar( new Long( 12 ) );
            arbol.insertar( new Long( 1 ) );
            arbol.insertar( new Long( 13 ) );
            arbol.insertar( new Long( 5 ) );
            arbol.insertar( new Long( 10 ) );
            arbol.insertar( new Long( 11 ) );
            arbol.eliminar( new Long( 15 ) );
            arbol.eliminar( new Long( 30 ) );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 3", new Long( 3 ), ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 7", new Long( 7 ), ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 12", new Long( 12 ), ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 1", new Long( 1 ), ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 2", new Long( 2 ), ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 4", new Long( 4 ), ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 5", new Long( 5 ), ( Long )hijo2.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 6", new Long( 6 ), ( Long )hijo2.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 10", new Long( 10 ), ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 11", new Long( 11 ), ( Long )hijo3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 13", new Long( 13 ), ( Long )hijo4.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );
        }
        catch( ElementoNoExisteException e )
        {
            fail( e.getMessage( ) );
        }
        catch( ElementoExisteException e )
        {
            fail( e.getMessage( ) );
        }

    }

    /**
     * Verifica que los elementos que no se encuentran en las hojas se eliminen correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEliminar4Orden4( )
    {
        setupEscenario2Orden4( );

        Long[] elementos = new Long[11];

        for( int cont = 0; cont < 11; cont++ )
        {
            elementos[ cont ] = new Long( cont );
        }

        try
        {
            // Caso Q
            arbol.eliminar( elementos[ 0 ] );
            arbol.eliminar( elementos[ 2 ] );
            arbol.eliminar( elementos[ 3 ] );

            NodoB raiz = arbol.darRaiz( );
            NodoB hijo1 = raiz.darHijo( 0 );
            NodoB hijo2 = raiz.darHijo( 1 );
            NodoB hijo3 = raiz.darHijo( 2 );
            NodoB hijo4 = raiz.darHijo( 3 );
            NodoB hijo1_1 = hijo1.darHijo( 0 );
            NodoB hijo1_2 = hijo1.darHijo( 1 );
            NodoB hijo1_3 = hijo1.darHijo( 2 );
            NodoB hijo1_4 = hijo1.darHijo( 3 );

            NodoB hijo2_1 = hijo2.darHijo( 0 );
            NodoB hijo2_2 = hijo2.darHijo( 1 );
            NodoB hijo2_3 = hijo2.darHijo( 2 );
            NodoB hijo2_4 = hijo2.darHijo( 3 );

            NodoB hijo3_1 = hijo3.darHijo( 0 );
            NodoB hijo3_2 = hijo3.darHijo( 1 );
            NodoB hijo3_3 = hijo3.darHijo( 2 );
            NodoB hijo3_4 = hijo3.darHijo( 3 );

            NodoB hijo4_1 = hijo4.darHijo( 0 );
            NodoB hijo4_2 = hijo4.darHijo( 1 );
            NodoB hijo4_3 = hijo4.darHijo( 2 );
            NodoB hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )hijo2.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );

            // Caso Q
            setupEscenario2Orden4( );
            arbol.eliminar( elementos[ 10 ] );
            arbol.eliminar( elementos[ 9 ] );
            arbol.eliminar( elementos[ 7 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 5", elementos[ 5 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )hijo3.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )hijo3.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertNull( "El elemento deber�a ser null", hijo4 );
            verificarInvariante( );

            // Eliminar un elemento de la ra�z
            setupEscenario2Orden4( );
            arbol.eliminar( elementos[ 5 ] );

            raiz = arbol.darRaiz( );
            hijo1 = raiz.darHijo( 0 );
            hijo2 = raiz.darHijo( 1 );
            hijo3 = raiz.darHijo( 2 );
            hijo4 = raiz.darHijo( 3 );
            hijo1_1 = hijo1.darHijo( 0 );
            hijo1_2 = hijo1.darHijo( 1 );
            hijo1_3 = hijo1.darHijo( 2 );
            hijo1_4 = hijo1.darHijo( 3 );

            hijo2_1 = hijo2.darHijo( 0 );
            hijo2_2 = hijo2.darHijo( 1 );
            hijo2_3 = hijo2.darHijo( 2 );
            hijo2_4 = hijo2.darHijo( 3 );

            hijo3_1 = hijo3.darHijo( 0 );
            hijo3_2 = hijo3.darHijo( 1 );
            hijo3_3 = hijo3.darHijo( 2 );
            hijo3_4 = hijo3.darHijo( 3 );

            hijo4_1 = hijo4.darHijo( 0 );
            hijo4_2 = hijo4.darHijo( 1 );
            hijo4_3 = hijo4.darHijo( 2 );
            hijo4_4 = hijo4.darHijo( 3 );

            assertEquals( "La altura retornada no es correcta", 2, arbol.darAltura( ) ); // verificar la altura del arbol
            assertEquals( "El elemento deber�a ser 2", elementos[ 2 ], ( Long )raiz.darRaiz( 0 ) ); // Verificar el contenido de los nodos
            assertEquals( "El elemento deber�a ser 6", elementos[ 6 ], ( Long )raiz.darRaiz( 1 ) );
            assertEquals( "El elemento deber�a ser 8", elementos[ 8 ], ( Long )raiz.darRaiz( 2 ) );
            assertEquals( "El elemento deber�a ser 0", elementos[ 0 ], ( Long )hijo1.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 1", elementos[ 1 ], ( Long )hijo1.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo1_1 );
            assertNull( "El elemento deber�a ser null", hijo1_2 );
            assertNull( "El elemento deber�a ser null", hijo1_3 );
            assertNull( "El elemento deber�a ser null", hijo1_4 );

            assertEquals( "El elemento deber�a ser 3", elementos[ 3 ], ( Long )hijo2.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 4", elementos[ 4 ], ( Long )hijo2.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", hijo2_1 );
            assertNull( "El elemento deber�a ser null", hijo2_2 );
            assertNull( "El elemento deber�a ser null", hijo2_3 );
            assertNull( "El elemento deber�a ser null", hijo2_4 );

            assertEquals( "El elemento deber�a ser 7", elementos[ 7 ], ( Long )hijo3.darRaiz( 0 ) );
            assertNull( "El elemento deber�a ser null", hijo3_1 );
            assertNull( "El elemento deber�a ser null", hijo3_2 );
            assertNull( "El elemento deber�a ser null", hijo3_3 );
            assertNull( "El elemento deber�a ser null", hijo3_4 );

            assertEquals( "El elemento deber�a ser 9", elementos[ 9 ], ( Long )hijo4.darRaiz( 0 ) );
            assertEquals( "El elemento deber�a ser 10", elementos[ 10 ], ( Long )hijo4.darRaiz( 1 ) );
            assertNull( "El elemento deber�a ser null", ( Long )hijo4.darRaiz( 2 ) );
            assertNull( "El elemento deber�a ser null", hijo4_1 );
            assertNull( "El elemento deber�a ser null", hijo4_2 );
            assertNull( "El elemento deber�a ser null", hijo4_3 );
            assertNull( "El elemento deber�a ser null", hijo4_4 );
            verificarInvariante( );
        }
        catch( ElementoNoExisteException e )
        {
            fail( e.getMessage( ) );
        }
    }

}
