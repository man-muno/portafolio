/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Framework: Cupi2Collections
 * Autor: Juan Erasmo Gómez - 4/02/2008
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package uniandes.cupi2.collections.arbolRojoNegro;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * Implementaci�n de un �rbol binario balanceado por el m�todo rojo-negro.
 * 
 * @author Juan Erasmo G�mez
 * 
 * @param <T> Tipo de información almacenada por el árbol.
 */
public class ArbolRojoNegro<T extends Comparable<? super T>> implements Serializable
{

    /**
     * Raiz del árbol.
     */
    private NodoRojoNegro<T> raiz;

    /**
     * Constructor por defecto.
     * </p>
     * Construye un árbol vacio.
     */
    public ArbolRojoNegro( )
    {
        raiz = null;
    }

    /**
     * Inserta un nuevo elemento en el árbol.
     * 
     * @param elem Elemento a insertar.
     * @throws ExisteException Si el elemento a insertar ya se encuentra en el árbol
     */
    public void insertar( T elem ) throws ExisteException
    {
        // Crear el nuevo nodo y agregarlo como si el arbol fuera un arbol
        // binario normal
        NodoRojoNegro<T> nodo = new NodoRojoNegro<T>( elem );

        NodoRojoNegro<T> r2 = null;

        if( raiz == null )
        {
            raiz = nodo;
            raiz.cambiarColor( NodoRojoNegro.NEGRO );
        }
        else
        {
            r2 = raiz.insertar( nodo );
        }

        raiz = r2 != null && r2.darPadre( ) == null ? r2 : raiz;
    }

    /**
     * Eliminar un elemento del árbol.
     * 
     * @param elem Elemento a eliminar del árbol.
     * @throws NoExisteException Si el elemento a eliminar no es encontrado en el árbol.
     */
    public void eliminar( T elem ) throws NoExisteException
    {
        if( raiz == null )
            throw new NoExisteException( "El árbol se encuentra vacio" );
        if( raiz.darInfoNodo( ).compareTo( elem ) == 0 && raiz.hijoDerechoHoja( ) && raiz.hijoIzquierdoHoja( ) )
            raiz = null;
        else
        {
            NodoRojoNegro<T> r2 = raiz.darNodo( elem ).eliminar( );
            raiz = r2 != null && r2.darPadre( ) == null ? r2 : raiz;
        }
    }

    /**
     * Retorna una lista con los elementos del árbol en preorden.
     * 
     * @return Una lista con los elementos del árbol en preorden.
     */
    public List<T> darPreorden( )
    {
        List<T> preorden = new LinkedList<T>( );
        if( raiz != null )
            raiz.darPreorden( preorden );
        return preorden;
    }

    /**
     * Verifica si un elemento existe en el arbol.
     * 
     * @param elem Elemento a buscar en el arbol.
     * @return <code>true</code> si el elemento es encontrado en el arbol o <code>false</code> en caso contrario.
     */
    public boolean existe( T elem )
    {
        return raiz != null ? raiz.existe( elem ) : false;
    }

    /**
     * Retorna la raiz del árbol.
     * 
     * @return La raiz del árbol.
     */
    public NodoRojoNegro<T> darRaiz( )
    {
        return raiz;
    }

    /**
     * Retorna el número de elementos del arbol.
     * 
     * @return El número de elementos del arbol.
     */
    public int darPeso( )
    {
        return raiz == null ? 0 : raiz.darPeso( );
    }

    /**
     * Retorna la altura del árbol.
     * 
     * @return La altura del árbol.
     */
    public int darAltura( )
    {
        return raiz == null ? 0 : raiz.darAltura( );
    }

    /**
     * Retorna el menor elemento del árbol.
     * 
     * @return El menor elemento del árbol o <code>null</code> si el árbol esta vacio.
     */
    public T darMinimo( )
    {
        return raiz == null ? null : raiz.darMenor( ).darInfoNodo( );
    }

    /**
     * Retorna el mayor elemento del árbol.
     * 
     * @return El mayor elemento del árbol o <code>null</code> si el árbol esta vacio.
     */
    public T darMayor( )
    {
        return raiz == null ? null : raiz.darMayor( ).darInfoNodo( );
    }
}