package uniandes.cupi2.collections.arbolB.test;

import uniandes.cupi2.collections.arbol.arbolB.ArbolB;
import uniandes.cupi2.collections.arbol.arbolB.NodoB;

/**
 * Clase utilizada para verificar la estructura del �rbol B
 * 
 */

public class VerificadorEstructura<T extends Comparable<? super T>>
{

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------
    /**
     * Informa si los elementos de la estructura est�n ordenados, y no hay elementos repetidos, teniendo en cuenta que en el recorrido en inorden, ret.ant es el �ltimo
     * elemento visitado. ret.ant es null, cuando no ha visitado ning�n objeto
     * 
     * @param ret El �ltimo elemento visitado en la estructura
     * @param nodo El nodo a partir del cual se va a verificar la estructura
     * @return El objeto con la informaci�n de si el orden es correcto y el �ltimo elemento visitado
     */
    @SuppressWarnings("unchecked")
    private Retorno2 verificarOrden( Retorno2 ret, NodoB<T> nodo )
    {
        if( nodo != null )
        {
            for( int i = 0; i < nodo.darCantidadRaices( ) + 1; i++ )
            {
                ret = ( nodo.darHijo( i ) == null ) ? ret : verificarOrden( ret, nodo.darHijo( i ) );
                T temp = nodo.darRaiz( i );
                if( ret.todoOK && temp != null )
                {
                    if( ret.ant != null && temp.compareTo( ret.ant ) <= 0 )
                        ret.todoOK = false;
                    else
                    {
                        ret.ant = temp;
                    }
                }
            }
        }
        return ret;
    }

    /**
     * Si la estructura del �rbol es correcta, de acuerdo con la definici�n de un �rbol B se retorna true o false de lo contrario.
     * @param nodo Nodo a partir del cual se va a realizar la verificaci�n
     * @return True si la estructura es correcta o false de lo contrario
     */
    @SuppressWarnings("unchecked")
    private boolean verificarEstructura( NodoB<T> nodo )
    {

        if( nodo != null )
        {
            boolean orden = true;
            for( int i = 0; i < nodo.darCantidadRaices( ) && !orden; i++ )
            {
                orden = nodo.darRaiz( i + 1 ) != null && ( nodo.darRaiz( i ).compareTo( nodo.darRaiz( i + 1 ) ) >= 0 );
                if( !orden )
                {
                    return orden;
                }
            }
            if( nodo.darCantidadHijos( ) != 0 )
            {
                int alturaAnterior = nodo.darHijo( 0 ).darAltura( );
                for( int i = 1; i < nodo.darCantidadHijos( ); i++ )
                {
                    if( alturaAnterior != nodo.darHijo( i ).darAltura( ) )
                        return false;
                }
                for( int i = 0; i < nodo.darCantidadHijos( ); i++ )
                {
                    verificarEstructura( nodo.darHijo( i ) );
                }
            }
        }

        return true;
    }

    /**
     * Verifica que tanto la estructura como el orden en el �rbol sean correctos
     * 
     * @param arbol Arbol a ser verificado
     * @return True si la estructura y orden del �rbol es correcta o false de lo contrario
     */
    // @SuppressWarnings("unchecked")
    public boolean verificarArbol( ArbolB<T> arbol )
    {
        Retorno2 ret = verificarOrden( new Retorno2( ), arbol.darRaiz( ) );
        return ret.todoOK && verificarEstructura( arbol.darRaiz( ) );
    }

    // -----------------------------------------------------------------
    // Clases Privadas
    // -----------------------------------------------------------------

    /**
     * Clase interna: Estructura para retornar la informaci�n del recorrido del �rbol, mientras establece si est� ordenado
     */
    private class Retorno2
    {
        boolean todoOK; // Hasta el momento el �rbol es ordenado

        T ant; // Ultimo elemento recorrido

        // Constructora
        Retorno2( )
        {
            todoOK = true;
            ant = null;
        }
    }
}
