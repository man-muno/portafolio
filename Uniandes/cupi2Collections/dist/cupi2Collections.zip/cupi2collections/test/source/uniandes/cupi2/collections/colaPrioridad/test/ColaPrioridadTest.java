package uniandes.cupi2.collections.colaPrioridad.test;

import uniandes.cupi2.collections.colaPrioridad.ColaVaciaException;
import uniandes.cupi2.collections.colaPrioridad.ColaPrioridad;
import uniandes.cupi2.collections.colaPrioridad.NodoColaPrioridad;
import junit.framework.TestCase;

/**
 * Esta es la clase usada para verificar los m�todos de la clase ColaPrioridad
 */
public class ColaPrioridadTest extends TestCase
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    /**
     * Es la clase donde se har�n las pruebas
     */
    private ColaPrioridad cola;

    /**
     * El n�mero de elementos a manejar en cada escenario
     */
    private int numeroElementos;

    /**
     * Objeto para verificar el invariante de la estructura
     */
    private VerificadorEstructura verificador;

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Construye una nueva cola de prioridad vac�a de Integers y de elementos String
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario1( )
    {
        cola = new ColaPrioridad<Integer, String>( );
        numeroElementos = 800;
        verificador = new VerificadorEstructura<Integer, String>( );
    }

    /**
     * Construye una nueva cola con 700 elementos inicializados cuyo valor de la prioridad posici�n por 3 y el mismo valor como elemento pero String
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario2( )
    {
        numeroElementos = 700;
        cola = new ColaPrioridad<Integer, String>( );

        for( int cont = 0; cont < numeroElementos; cont++ )
        {
            cola.insertar( new Integer( cont * 3 ), new Integer( cont * 3 ) + "" );
        }
        verificador = new VerificadorEstructura<Integer, String>( );
    }

    /**
     * Construye una nueva cola con 1000 elementos inicializados con la el valor de la prioridad con posicion por -5 y el mismo valor para elemento pero String
     * 
     */
    @SuppressWarnings("unchecked")
    public void setupEscenario3( )
    {
        numeroElementos = 1000;
        cola = new ColaPrioridad<Long, String>( );

        for( int cont = 0; cont < numeroElementos; cont++ )
        {
            cola.insertar( new Long( cont * ( -5 ) ), new Long( cont * ( -5 ) ) );
        }
        verificador = new VerificadorEstructura<Integer, String>( );
    }

    /**
     * Verifica que la estructura en la cola sea correcta
     * 
     */
    @SuppressWarnings("unchecked")
    private void verificarInvariante( )
    {
        boolean estructuraBien = ( verificador.verificarCola( cola ) );

        assertTrue( "La estructura y/o el orden en la cola no es correcta", estructuraBien );
    }

    /**
     * Prueba que los elementos se est�n ingresando correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsertar1( )
    {
        setupEscenario1( );

        for( int cont = numeroElementos - 1; cont >= 0; cont-- )
        {
            cola.insertar( new Integer( 20 * cont ), null );
            verificarInvariante( );
        }

        // Verificar que la pila tenga la longitud correcta
        assertEquals( "No se adicionaron todos los elementos", numeroElementos, cola.darLongitud( ) );

        // Verificar que todos los elementos hayan sido adicionados y en el orden correcto
        NodoColaPrioridad nodo = ( NodoColaPrioridad )cola.darPrimero( );

        int cont = numeroElementos - 1;
        while( nodo != null )
        {
            Integer prioridad = ( Integer )nodo.darPrioridad( );

            assertEquals( "El valor en la posici�n " + ( numeroElementos - cont - 1 ) + " no se agrego de forma correcta", 20 * cont, prioridad.intValue( ) );

            nodo = nodo.darSiguiente( );
            cont--;
        }
    }

    /**
     * Prueba que los elementos se est�n ingresando correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsertar2( )
    {
        setupEscenario1( );

        for( int cont = 0; cont < numeroElementos; cont++ )
        {
            cola.insertar( new Integer( numeroElementos - cont ), null );
            verificarInvariante( );
        }

        // Verificar que la cola tenga la longitud correcta
        assertEquals( "No se adicionaron todos los elementos", numeroElementos, cola.darLongitud( ) );

        // Verificar que todos los elementos hayan sido adicionados y en el orden correcto
        NodoColaPrioridad nodo = ( NodoColaPrioridad )cola.darPrimero( );
        int cont = numeroElementos;

        while( nodo != null )
        {
            Integer prioridad = ( Integer )nodo.darPrioridad( );

            assertEquals( "El valor en la posici�n " + ( numeroElementos - cont ) + " no se agrego de forma correcta", cont, prioridad.intValue( ) );

            nodo = nodo.darSiguiente( );
            cont--;

        }
    }

    /**
     * Prueba que los elementos se est�n ingresando correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testInsertar3( )
    {
        setupEscenario1( );

        // Insertar 5 elementos en ordenes distintos
        cola.insertar( new Integer( 65 ), null );
        verificarInvariante( );

        cola.insertar( new Integer( -100 ), null );
        verificarInvariante( );

        cola.insertar( new Integer( 100 ), null );
        verificarInvariante( );

        cola.insertar( new Integer( 20 ), null );
        verificarInvariante( );

        cola.insertar( new Integer( 20 ), null );
        verificarInvariante( );

        cola.insertar( new Integer( 113 ), null );
        verificarInvariante( );

        // Verificar que la cola tenga la longitud correcta
        assertEquals( "No se adicionaron todos los elementos", 6, cola.darLongitud( ) );

        // Verificar que todos los elementos hayan sido adicionados y en el orden correcto
        NodoColaPrioridad nodo = ( NodoColaPrioridad )cola.darPrimero( );

        Integer prioridad = ( Integer )nodo.darPrioridad( );

        assertEquals( "El valor 113 no se agrego de forma correcta", 113, prioridad.intValue( ) );

        nodo = nodo.darSiguiente( );

        prioridad = ( Integer )nodo.darPrioridad( );

        assertEquals( "El valor 100 no se agrego de forma correcta", 100, prioridad.intValue( ) );

        nodo = nodo.darSiguiente( );

        prioridad = ( Integer )nodo.darPrioridad( );

        assertEquals( "El valor 65 no se agrego de forma correcta", 65, prioridad.intValue( ) );

        nodo = nodo.darSiguiente( );

        prioridad = ( Integer )nodo.darPrioridad( );

        assertEquals( "El valor 20 no se agrego de forma correcta", 20, prioridad.intValue( ) );

        nodo = nodo.darSiguiente( );

        prioridad = ( Integer )nodo.darPrioridad( );

        assertEquals( "El valor 20 no se agrego de forma correcta", 20, prioridad.intValue( ) );

        nodo = nodo.darSiguiente( );

        prioridad = ( Integer )nodo.darPrioridad( );

        assertEquals( "El valor -100 no se agrego de forma correcta", -100, prioridad.intValue( ) );

    }

    /**
     * Prueba que todos los elementos se est�n eliminando correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testTomarElemento1( )
    {
        setupEscenario2( );

        try
        {
            for( int cont = numeroElementos - 1; cont >= 0; cont-- )
            {
                String elemento = ( String )cola.tomarElemento( );
                verificarInvariante( );
                assertEquals( "No se tom� el elemento correcto", cont * 3 + "", elemento );

            }
        }
        catch( ColaVaciaException e )
        {
            e.printStackTrace( );
        }

        // Verificar que la pila tenga la longitud correcta
        assertEquals( "No eliminaron todos los elementos", 0, cola.darLongitud( ) );
    }

    /**
     * Prueba que se retorne null al tomar un elemento de una cola vac�a
     * 
     */
    @SuppressWarnings("unchecked")
    public void testTomarElemento2( )
    {
        setupEscenario1( );
        Integer elemento = null;

        try
        {
            elemento = ( Integer )cola.tomarElemento( );
            assertNull( "No se debio haber tomado nada", elemento );
        }
        catch( ColaVaciaException e )
        {
            assertNull( "No se debio tomado nada ", elemento );
            verificarInvariante( );
        }
    }

    /**
     * Prueba que la cola siga consistente al tomar 5 elementos de esta
     * 
     */
    @SuppressWarnings("unchecked")
    public void testTomarElemento3( )
    {
        setupEscenario3( );

        try
        {

            Long elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", 0, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -5, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -10, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -15, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -20, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -25, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -30, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -35, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -40, elemento.intValue( ) );
            verificarInvariante( );

            elemento = ( Long )cola.tomarElemento( );

            assertEquals( "No se tom� el elemento correcto", -45, elemento.intValue( ) );
            verificarInvariante( );

        }
        catch( ColaVaciaException e )
        {

            e.printStackTrace( );
        }

        // Verificar que la cola tenga la longitud correcta
        assertEquals( "No eliminaron todos los elementos", numeroElementos - 10, cola.darLongitud( ) );
    }

    /**
     * Verifica que se indique correctamente si una cola est� vacia o no
     * 
     */
    @SuppressWarnings("unchecked")
    public void testEstaVacia( )
    {
        setupEscenario1( );

        boolean vacia = cola.estaVacia( );

        assertEquals( "La cola deber�a estar vac�a", true, vacia );

        setupEscenario2( );

        vacia = cola.estaVacia( );

        assertEquals( "La cola no deber�a estar vac�a", false, vacia );

        try
        {
            for( int cont = numeroElementos - 1; cont >= 0; cont-- )
            {
                String elemento = ( String )cola.tomarElemento( );

                assertEquals( "No se tom� el elemento correcto", cont * 3 + "", elemento );

            }
        }
        catch( ColaVaciaException e )
        {

            e.printStackTrace( );
        }

        vacia = cola.estaVacia( );

        assertEquals( "La cola deber�a estar vac�a", true, vacia );

    }

    /**
     * Prueba que se retorne la longitud de la cola correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testDarLongitud( )
    {
        setupEscenario2( );

        // Verificar que la longitud de la cola sea correcta
        assertEquals( "La longitud no se retorno correctamente", numeroElementos, cola.darLongitud( ) );

        try
        {
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );

            assertEquals( "La longitud no se retorno correctamente", numeroElementos - 12, cola.darLongitud( ) );

            cola.tomarElemento( );
            cola.tomarElemento( );
            cola.tomarElemento( );

            assertEquals( "La longitud no se retorno correctamente", numeroElementos - 15, cola.darLongitud( ) );
        }
        catch( ColaVaciaException e )
        {

            e.printStackTrace( );
        }
    }

    /**
     * Prueba que el m�todo toString de la cola funcione correctamente
     * 
     */
    @SuppressWarnings("unchecked")
    public void testToString( )
    {

        // Verificar que la lista sea vaciada
        setupEscenario3( );

        String colaS = cola.toString( );

        // Construir el string espererado para la prueba
        String resp = "[" + numeroElementos + "]:";
        for( int i = 0; i < numeroElementos; i++ )
        {
            resp += "->(" + ( new Long( i * ( -5 ) ) ).toString( ) + "," + ( new Long( i * ( -5 ) ) ).toString( ) + ")";
        }

        assertEquals( "El m�todo toString no funciona correctamente", resp, colaS );
    }

    /**
     * Prueba que se retorne correctamente el primer elemento de la pila
     * 
     */
    @SuppressWarnings("unchecked")
    public void testDarPrimero( )
    {
        setupEscenario2( );

        NodoColaPrioridad nodo = cola.darPrimero( );

        String elemento = ( String )nodo.darElemento( );

        // Verificar que el primero elemento sea el correcto
        assertEquals( "El primer elemento no es correcto", 2097 + "", elemento );

        // Verificar que el encadenamiento entre los nodos sea correcto
        NodoColaPrioridad aux = nodo;
        nodo = nodo.darSiguiente( );

        int cont = 1;
        while( nodo != null )
        {
            aux = nodo;
            nodo = nodo.darSiguiente( );
            cont++;
        }

        // Verificar que el nodo siguiente al ultimo sea null
        assertNull( "El siguiente elemento deber�a ser null", aux.darSiguiente( ) );

        // Verificar que el valor del �ltimo elemento sea correcto
        String elemen = ( String )aux.darElemento( );
        assertEquals( "El n�mero de nodos no correcponde al n�mero de elementos", 0 + "", elemen );

        // Verificar que el n�mero de nodos sea igual al n�mero de elementos
        assertEquals( "El n�mero de nodos no correcponde al n�mero de elementos", numeroElementos, cont );
    }
}
