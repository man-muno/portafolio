package uniandes.cupi2.collections.arbolRojoNegro.test;

public class EstructuraException extends Exception
{

    public EstructuraException( String msg )
    {
        super( msg );
    }

}
